"""Acoustic diagnostics — ConvAutoencoder on CUDA. Full GUI."""

import os, sys, threading, traceback, logging, tempfile, argparse, json, shutil
from datetime import datetime
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")

from flask import Flask, jsonify, render_template, request, send_file
from werkzeug.utils import secure_filename

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(os.path.join(ROOT, "app.log"), encoding="utf-8"),
    ],
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config["SECRET_KEY"] = "mimii-228"
PORT = 228

from src.config import MODEL_DIR, DATA_DIR, MACHINE_TYPES, RESULTS_DIR, BATCH_SIZE, EPOCHS, LEARNING_RATE, PATIENCE, ANOMALY_QUANTILE
MODEL_DIR.mkdir(parents=True, exist_ok=True)
RESULTS_DIR.mkdir(parents=True, exist_ok=True)
MODEL_HISTORY_DIR = MODEL_DIR / "history"
MODEL_HISTORY_DIR.mkdir(parents=True, exist_ok=True)
MODEL_REGISTRY_PATH = MODEL_DIR / "model_registry.json"

state = {
    "status":           "idle",
    "progress":         0,
    "log":              [],
    "startup_log":      [],
    "results":          {},
    "available_models": [],
    "model_registry":   {},
    "train_history":    [],
    "device":           "cpu",
}
_model_cache: dict = {}  # machine_type -> {"model": ConvAutoencoder, "threshold": float}


def log(msg: str, startup: bool = False):
    (state["startup_log"] if startup else state["log"]).append(msg)
    logger.info(msg)


def _model_path(mt: str) -> Path:
    return MODEL_DIR / f"conv_ae_{mt}.pt"


def _threshold_path(mt: str) -> Path:
    return MODEL_DIR / f"conv_ae_{mt}_threshold.npy"


def _warmup_autoencoder(model, device):
    """Initialize lazy FC layers before loading checkpoint weights."""
    import torch
    from src.config import SAMPLE_RATE, WINDOW_SEC
    from src.dataset import extract_mel_spectrogram

    y = np.zeros(int(SAMPLE_RATE * WINDOW_SEC), dtype=np.float32)
    mel = extract_mel_spectrogram(y)
    x = torch.from_numpy(mel).float().unsqueeze(0).unsqueeze(0).to(device)
    with torch.no_grad():
        model(x)
    return model


def _extract_state_dict(raw_obj):
    if isinstance(raw_obj, dict) and "state_dict" in raw_obj and isinstance(raw_obj["state_dict"], dict):
        return raw_obj["state_dict"]
    return raw_obj


def _checkpoint_compatibility(model, state_dict: dict):
    model_sd = model.state_dict()
    missing = []
    mismatched = []
    unexpected = []

    for k, v in state_dict.items():
        if k not in model_sd:
            unexpected.append(k)
            continue
        if tuple(v.shape) != tuple(model_sd[k].shape):
            mismatched.append((k, tuple(v.shape), tuple(model_sd[k].shape)))

    for k in model_sd.keys():
        if k not in state_dict:
            missing.append(k)

    if missing or mismatched:
        parts = []
        if missing:
            parts.append(f"missing={len(missing)}")
        if mismatched:
            ex = ", ".join([f"{k}:{old}->{new}" for k, old, new in mismatched[:2]])
            parts.append(f"shape_mismatch={len(mismatched)} ({ex})")
        if unexpected:
            parts.append(f"unexpected={len(unexpected)}")
        return False, "; ".join(parts)
    return True, "ok"


def _load_model_weights_checked(model, path: Path, device):
    import torch
    raw = torch.load(path, map_location=device, weights_only=True)
    state_dict = _extract_state_dict(raw)
    ok, reason = _checkpoint_compatibility(model, state_dict)
    if not ok:
        raise ValueError(reason)
    model.load_state_dict(state_dict)
    return model


def _load_registry() -> dict:
    if not MODEL_REGISTRY_PATH.exists():
        return {"models": []}
    try:
        with MODEL_REGISTRY_PATH.open("r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(data.get("models"), list):
            return data
    except Exception as e:
        log(f"WARNING registry load failed: {e}", startup=True)
    return {"models": []}


def _save_registry(registry: dict):
    tmp = MODEL_REGISTRY_PATH.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(registry, f, ensure_ascii=False, indent=2)
    tmp.replace(MODEL_REGISTRY_PATH)


def _refresh_registry_state(registry: dict):
    grouped = {}
    for rec in registry.get("models", []):
        grouped.setdefault(rec["machine_type"], []).append(rec)
    for mt in grouped:
        grouped[mt].sort(key=lambda x: x.get("created_at", ""), reverse=True)
    state["model_registry"] = grouped
    all_items = sorted(registry.get("models", []), key=lambda x: x.get("created_at", ""), reverse=True)
    state["train_history"] = all_items[:30]


def _register_model(machine_type: str, snr_db: int, threshold: float, metrics: dict,
                    mode: str, base_model_id: str | None, epochs_trained: int,
                    model_path: Path, threshold_path: Path):
    registry = _load_registry()
    model_id = f"{machine_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    rec = {
        "id": model_id,
        "machine_type": machine_type,
        "snr": snr_db,
        "mode": mode,
        "base_model_id": base_model_id,
        "epochs_trained": epochs_trained,
        "threshold": round(float(threshold), 6),
        "auc_roc": round(float(metrics.get("auc_roc", 0.0)), 4),
        "pauc": round(float(metrics.get("pauc", 0.0)), 4),
        "f1": round(float(metrics.get("f1", 0.0)), 4),
        "accuracy": round(float(metrics.get("accuracy", 0.0)), 4),
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "model_path": str(model_path.relative_to(ROOT)),
        "threshold_path": str(threshold_path.relative_to(ROOT)),
    }
    registry["models"].append(rec)
    _save_registry(registry)
    _refresh_registry_state(registry)
    return rec


def _latest_model_record(machine_type: str) -> dict | None:
    registry = _load_registry()
    items = [m for m in registry.get("models", []) if m.get("machine_type") == machine_type]
    if not items:
        return None
    items.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    return items[0]


def _partial_auc(y_true, scores, max_fpr=0.1):
    from sklearn.metrics import roc_curve
    fpr, tpr, _ = roc_curve(y_true, scores)
    mask = fpr <= max_fpr
    if mask.sum() < 2:
        return 0.0
    _trapz = np.trapezoid if hasattr(np, "trapezoid") else np.trapz
    return float(_trapz(tpr[mask], fpr[mask]) / max_fpr)


def _preload():
    import torch
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    state["device"] = "cuda" if torch.cuda.is_available() else "cpu"

    registry = _load_registry()
    _refresh_registry_state(registry)

    from src.autoencoder import ConvAutoencoder
    for mt in MACHINE_TYPES:
        mp = _model_path(mt)
        tp = _threshold_path(mt)
        if mp.exists() and tp.exists():
            try:
                model = ConvAutoencoder().to(device)
                _warmup_autoencoder(model, device)
                _load_model_weights_checked(model, mp, device)
                model.eval()
                threshold = float(np.load(tp))
                _model_cache[mt] = {"model": model, "threshold": threshold}
                state["available_models"].append(mt)
                log(f"Loaded: conv_ae_{mt}.pt  thr={threshold:.6f}", startup=True)
            except Exception as e:
                log(f"WARNING {mt}: incompatible checkpoint for current config ({e})", startup=True)

    if not state["available_models"]:
        log("No trained models found. Use Train tab.", startup=True)


# ── Routes ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/state")
def get_state():
    return jsonify({
        "status":           state["status"],
        "progress":         state["progress"],
        "log":              state["log"][-120:],
        "startup_log":      state["startup_log"],
        "results":          state["results"],
        "available_models": state["available_models"],
        "model_registry":   state["model_registry"],
        "train_history":    state["train_history"],
        "device":           state["device"],
    })


@app.route("/api/images")
def list_images():
    imgs = [f.name for f in sorted(RESULTS_DIR.glob("*.png"))] if RESULTS_DIR.exists() else []
    return jsonify(imgs)


@app.route("/results/<path:filename>")
def serve_result(filename):
    return send_file(RESULTS_DIR / filename)


@app.route("/api/download", methods=["POST"])
def download_data():
    if state["status"] == "running":
        return jsonify({"error": "Busy"}), 409
    machine_type = (request.json or {}).get("machine_type", "fan")

    def _run():
        state.update({"status": "running", "progress": 0, "log": [], "results": {}})
        try:
            from src.download import download_mimii
            def progress_cb(downloaded, total):
                if total:
                    state["progress"] = max(1, min(95, int(downloaded / total * 95)))
            log(f"Downloading MIMII: {machine_type}…")
            download_mimii([machine_type], progress_cb=progress_cb)
            state["progress"] = 100
            log("Download complete!")
        except Exception as e:
            log(f"ERROR: {e}")
            traceback.print_exc()
        finally:
            state["status"] = "idle"

    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/train", methods=["POST"])
def train():
    if state["status"] == "running":
        return jsonify({"error": "Busy"}), 409
    data         = request.json or {}
    machine_type = data.get("machine_type", "fan")
    snr_db       = int(data.get("snr", 6))
    train_mode   = data.get("train_mode", "new")
    base_model_id = (data.get("base_model_id") or "").strip() or None

    def _run():
        state.update({"status": "running", "progress": 5, "log": [], "results": {}})
        try:
            import torch
            from torch.utils.data import DataLoader
            from src.dataset import build_datasets
            from src.autoencoder import ConvAutoencoder, train_autoencoder, compute_threshold
            from src.evaluate import evaluate_anomaly_detection, partial_auc
            from sklearn.metrics import (
                roc_auc_score, roc_curve, confusion_matrix,
                accuracy_score, f1_score, classification_report,
            )
            import matplotlib.pyplot as plt
            import seaborn as sns

            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            log(f"Device: {device}  CUDA={torch.cuda.is_available()}")
            if torch.cuda.is_available():
                log(f"GPU: {torch.cuda.get_device_name(0)}")
            log(f"Loading + precomputing spectrograms: {machine_type}…")
            state["progress"] = 8

            def precompute_cb(done, total):
                pct = 8 + int(done / total * 7)
                state["progress"] = pct
                if done <= total:
                    log(f"Preparing dataset files: {done}/{total}")
                else:
                    log(f"Precomputing spectrograms: {done-total}/{total}")

            train_ds, val_ds, test_ds, test_labels, _ = build_datasets(
                machine_type, snr_db=snr_db, augment_train=True, progress_cb=precompute_cb
            )
            log(f"train={len(train_ds)}  val={len(val_ds)}  test={len(test_ds)}")
            state["progress"] = 15

            # All data is precomputed tensors — num_workers=0 is optimal (no disk I/O)
            bs = BATCH_SIZE
            train_loader = DataLoader(train_ds, batch_size=bs, shuffle=True,
                                      num_workers=0, pin_memory=(str(device)=="cuda"))
            val_loader   = DataLoader(val_ds,   batch_size=bs, shuffle=False,
                                      num_workers=0, pin_memory=(str(device)=="cuda"))
            test_loader  = DataLoader(test_ds,  batch_size=bs, shuffle=False,
                                      num_workers=0, pin_memory=(str(device)=="cuda"))

            model = ConvAutoencoder().to(device)
            loaded_from = None
            if train_mode == "finetune":
                registry = _load_registry()
                candidates = [m for m in registry.get("models", []) if m.get("machine_type") == machine_type]
                if base_model_id:
                    candidates = [m for m in candidates if m.get("id") == base_model_id]
                candidates.sort(key=lambda x: x.get("created_at", ""), reverse=True)
                selected = candidates[0] if candidates else None
                if selected:
                    base_model_path = Path(ROOT) / selected["model_path"]
                    if base_model_path.exists():
                        log(f"Finetune from {selected['id']} ({base_model_path.name})")
                        _warmup_autoencoder(model, device)
                        try:
                            _load_model_weights_checked(model, base_model_path, device)
                            loaded_from = selected["id"]
                        except Exception as e:
                            log(f"WARNING finetune base incompatible: {e}. Fallback to new training.")
                    else:
                        log(f"WARNING base model missing: {base_model_path}. Fallback to new training.")
                else:
                    log("WARNING no base model found for finetune. Fallback to new training.")

            total_params = sum(p.numel() for p in model.parameters())
            log(f"ConvAutoencoder  params={total_params:,}  training on {device}…")
            state["progress"] = 18

            # epoch callback for live progress
            save_path = _model_path(machine_type)
            epochs_done = [0]

            def epoch_cb(epoch, t_loss, v_loss):
                epochs_done[0] = epoch
                pct = 18 + int(epoch / EPOCHS * 62)
                state["progress"] = min(pct, 80)
                log(f"Epoch {epoch:3d}/{EPOCHS} | train={t_loss:.4f} | val={v_loss:.4f}")

            # patch train_autoencoder to emit per-epoch callback
            model, history = _train_with_cb(
                model, train_loader, val_loader,
                epochs=EPOCHS, lr=LEARNING_RATE, patience=PATIENCE,
                device=device, save_path=save_path, cb=epoch_cb
            )
            state["progress"] = 80

            log("Computing threshold…")
            threshold = compute_threshold(model, val_loader, device, ANOMALY_QUANTILE)
            np.save(_threshold_path(machine_type), threshold)
            _model_cache[machine_type] = {"model": model, "threshold": threshold}
            if machine_type not in state["available_models"]:
                state["available_models"].append(machine_type)
            state["progress"] = 83

            log("Evaluating…")
            eval_res = evaluate_anomaly_detection(model, test_loader, test_labels, device, threshold)
            scores   = eval_res["errors"]
            auc      = float(roc_auc_score(test_labels, scores))
            pauc     = float(partial_auc(test_labels, scores))
            preds    = (scores > threshold).astype(int)
            state["progress"] = 87

            # ── plots ──
            log("Generating plots…")
            norm_scores = scores[test_labels == 0]
            abn_scores  = scores[test_labels == 1]

            # Score distribution
            fig, ax = plt.subplots(figsize=(10, 5))
            ax.hist(norm_scores, bins=60, alpha=0.65, label="Normal",   color="steelblue", density=True)
            ax.hist(abn_scores,  bins=60, alpha=0.65, label="Abnormal", color="tomato",    density=True)
            ax.axvline(threshold, color="black", linestyle="--", lw=2, label=f"thr={threshold:.4f}")
            ax.set_xlabel("Reconstruction Error (MSE)"); ax.set_ylabel("Density")
            ax.set_title(f"Score Distribution — {machine_type}"); ax.legend()
            plt.tight_layout(); fig.savefig(RESULTS_DIR / f"scores_{machine_type}.png", dpi=150)
            plt.close(fig)

            # ROC
            fpr, tpr, _ = roc_curve(test_labels, scores)
            fig, ax = plt.subplots(figsize=(7, 7))
            ax.plot(fpr, tpr, lw=2, label=f"AUC = {auc:.4f}")
            ax.plot([0,1],[0,1],"k--",lw=1)
            ax.set_xlabel("FPR"); ax.set_ylabel("TPR")
            ax.set_title(f"ROC — {machine_type}"); ax.legend(loc="lower right")
            plt.tight_layout(); fig.savefig(RESULTS_DIR / f"roc_{machine_type}.png", dpi=150)
            plt.close(fig)

            # Confusion matrix
            cm = confusion_matrix(test_labels, preds)
            fig, ax = plt.subplots(figsize=(5, 4))
            sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                        xticklabels=["Normal","Anomaly"],
                        yticklabels=["Normal","Anomaly"], ax=ax)
            ax.set_xlabel("Predicted"); ax.set_ylabel("True")
            ax.set_title(f"Confusion Matrix — {machine_type}")
            plt.tight_layout(); fig.savefig(RESULTS_DIR / f"cm_{machine_type}.png", dpi=150)
            plt.close(fig)

            # Training history
            fig, ax = plt.subplots(figsize=(8, 4))
            ax.plot(history["train_loss"], label="Train Loss")
            ax.plot(history["val_loss"],   label="Val Loss")
            ax.set_xlabel("Epoch"); ax.set_ylabel("MSE")
            ax.set_title(f"Training History — {machine_type}"); ax.legend()
            plt.tight_layout(); fig.savefig(RESULTS_DIR / f"history_{machine_type}.png", dpi=150)
            plt.close(fig)

            state["progress"] = 95
            state["results"]["train"] = {
                "machine_type": machine_type,
                "snr":          snr_db,
                "train_mode":   train_mode,
                "finetuned_from": loaded_from,
                "auc_roc":      round(auc, 4),
                "pauc":         round(pauc, 4),
                "threshold":    round(float(threshold), 6),
                "train_clips":  len(train_ds),
                "accuracy":     round(float(accuracy_score(test_labels, preds)), 4),
                "f1":           round(float(f1_score(test_labels, preds)), 4),
                "epochs_trained": len(history.get("train_loss", [])),
                "report":       classification_report(test_labels, preds,
                                                      target_names=["Normal","Anomaly"]),
            }
            run_record = _register_model(
                machine_type=machine_type,
                snr_db=snr_db,
                threshold=threshold,
                metrics=state["results"]["train"],
                mode=("finetune" if loaded_from else "new"),
                base_model_id=loaded_from,
                epochs_trained=len(history.get("train_loss", [])),
                model_path=save_path,
                threshold_path=_threshold_path(machine_type),
            )
            # snapshot each training run for history/versioning
            hist_model = MODEL_HISTORY_DIR / f"{run_record['id']}.pt"
            hist_thr = MODEL_HISTORY_DIR / f"{run_record['id']}_threshold.npy"
            shutil.copy2(save_path, hist_model)
            shutil.copy2(_threshold_path(machine_type), hist_thr)
            log(f"Saved history model: {run_record['id']}")
            state["progress"] = 100
            log(f"Done! AUC={auc:.4f}  pAUC={pauc:.4f}  thr={threshold:.6f}")

        except Exception as e:
            log(f"ERROR: {e}")
            traceback.print_exc()
        finally:
            state["status"] = "idle"

    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True})


def _train_with_cb(model, train_loader, val_loader, epochs, lr, patience,
                   device, save_path, cb):
    """train_autoencoder with per-epoch callback + AMP for GPU throughput."""
    import torch
    import torch.nn as nn
    from torch.amp import autocast, GradScaler

    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.MSELoss()
    use_amp = (str(device) == "cuda")
    scaler = GradScaler("cuda") if use_amp else None
    best_val, wait = float("inf"), 0
    history = {"train_loss": [], "val_loss": []}

    log(f"AMP={'ON' if use_amp else 'OFF'}  device={device}")

    for epoch in range(1, epochs + 1):
        model.train()
        tl = []
        for batch in train_loader:
            x = (batch[0] if isinstance(batch, (list, tuple)) else batch).to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            if use_amp:
                with autocast("cuda"):
                    x_hat, _ = model(x)
                    loss = criterion(x_hat, x)
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
            else:
                x_hat, _ = model(x)
                loss = criterion(x_hat, x)
                loss.backward()
                optimizer.step()
            tl.append(loss.item())

        model.eval()
        vl = []
        with torch.no_grad():
            for batch in val_loader:
                x = (batch[0] if isinstance(batch, (list, tuple)) else batch).to(device, non_blocking=True)
                if use_amp:
                    with autocast("cuda"):
                        x_hat, _ = model(x)
                        vl.append(criterion(x_hat, x).item())
                else:
                    x_hat, _ = model(x)
                    vl.append(criterion(x_hat, x).item())

        t_loss, v_loss = float(np.mean(tl)), float(np.mean(vl))
        history["train_loss"].append(t_loss)
        history["val_loss"].append(v_loss)
        cb(epoch, t_loss, v_loss)

        if v_loss < best_val:
            best_val, wait = v_loss, 0
            save_path.parent.mkdir(parents=True, exist_ok=True)
            torch.save(model.state_dict(), save_path)
        else:
            wait += 1
            if wait >= patience:
                log(f"Early stopping at epoch {epoch}")
                break

    if save_path.exists():
        model.load_state_dict(torch.load(save_path, weights_only=True, map_location=device))
    return model, history


@app.route("/api/check_upload", methods=["POST"])
def check_upload():
    if state["status"] == "running":
        return jsonify({"error": "Busy"}), 409

    files = request.files.getlist("files")
    if not files or not files[0].filename:
        return jsonify({"error": "No files uploaded"}), 400

    machine_type  = request.form.get("machine_type", "fan")
    model_id_raw  = (request.form.get("model_id", "") or "").strip()
    threshold_raw = request.form.get("threshold", "").strip()

    cache_key = f"{machine_type}:{model_id_raw or 'latest'}"
    cached = _model_cache.get(cache_key) or _model_cache.get(machine_type)
    if not cached:
        selected_path = None
        selected_thr_path = None
        if model_id_raw:
            reg = _load_registry()
            rec = next((m for m in reg.get("models", []) if m.get("id") == model_id_raw and m.get("machine_type") == machine_type), None)
            if not rec:
                return jsonify({"error": f"Model id '{model_id_raw}' not found for '{machine_type}'."}), 400
            selected_path = Path(ROOT) / rec["model_path"]
            selected_thr_path = Path(ROOT) / rec["threshold_path"]
        else:
            selected_path, selected_thr_path = _model_path(machine_type), _threshold_path(machine_type)

        if not selected_path.exists():
            return jsonify({"error": f"No model for '{machine_type}'. Train first."}), 400

        import torch
        from src.autoencoder import ConvAutoencoder
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model  = ConvAutoencoder().to(device)
        _warmup_autoencoder(model, device)
        try:
            _load_model_weights_checked(model, selected_path, device)
        except Exception as e:
            return jsonify({"error": f"Incompatible model checkpoint with current config: {e}"}), 400
        model.eval()
        threshold = float(np.load(selected_thr_path))
        cached = {"model": model, "threshold": threshold}
        _model_cache[cache_key] = cached
        _model_cache[machine_type] = cached

    model     = cached["model"]
    default_t = cached["threshold"]
    try:
        threshold = float(threshold_raw) if threshold_raw else default_t
    except ValueError:
        return jsonify({"error": "Threshold must be a number"}), 400

    saved = []
    for f in files:
        safe = secure_filename(f.filename or "audio.wav")
        tmp  = tempfile.NamedTemporaryFile(delete=False, suffix=Path(safe).suffix or ".wav")
        f.save(tmp.name)
        saved.append((safe, tmp.name))

    def _run():
        state.update({"status": "running", "progress": 10, "log": [], "results": {}})
        try:
            import torch
            from src.dataset import load_audio, window_signal, extract_mel_spectrogram
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            log(f"Checking {len(saved)} file(s) | {machine_type} | thr={threshold:.6f}")

            items, n_anom = [], 0
            for name, path in saved:
                y       = load_audio(Path(path))
                windows = window_signal(y)
                if not windows:
                    items.append({"name": name, "score": 0.0, "is_anomaly": False})
                    continue
                tensors = torch.stack([
                    torch.from_numpy(extract_mel_spectrogram(w)).float().unsqueeze(0)
                    for w in windows
                ]).to(device)
                with torch.no_grad():
                    errs = model.reconstruction_error(tensors).cpu().numpy()
                score   = float(errs.mean())
                is_anom = score > threshold
                n_anom += int(is_anom)
                items.append({"name": name, "score": round(score, 6), "is_anomaly": bool(is_anom)})

            state["results"]["upload_check"] = {
                "machine_type":  machine_type,
                "threshold":     round(threshold, 6),
                "total_files":   len(saved),
                "anomaly_count": n_anom,
                "items":         items,
            }
            state["progress"] = 100
            log(f"Done. Anomalies: {n_anom}/{len(saved)}")
        except Exception as e:
            log(f"ERROR: {e}")
            traceback.print_exc()
        finally:
            state["status"] = "idle"
            for _, p in saved:
                try: Path(p).unlink()
                except OSError: pass

    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--public", action="store_true")
    args = parser.parse_args()

    _preload()

    if args.public:
        try:
            import ngrok
            listener  = ngrok.forward(PORT, authtoken_from_env=True)
            public_url = listener.url()
            logger.info("=" * 52)
            logger.info(f"  PUBLIC URL: {public_url}")
            logger.info("=" * 52)
            print(f"\n  PUBLIC URL: {public_url}\n")
        except Exception as e:
            logger.warning(f"ngrok failed: {e}")

    import webbrowser
    webbrowser.open(f"http://localhost:{PORT}")
    app.run(host="0.0.0.0", port=PORT, debug=False)
