from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT_DIR / "data"
MODEL_DIR = ROOT_DIR / "models"
RESULTS_DIR = ROOT_DIR / "results"

SAMPLE_RATE = 16000
WINDOW_SEC = 3.0
HOP_SEC = 1.0  # 50% overlap
N_FFT = 2048
HOP_LENGTH = 256
N_MELS = 128
N_MFCC = 13

MACHINE_TYPES = ["fan", "pump", "slider", "valve"]

# SNR levels available in MIMII
SNR_LEVELS = [-6, 0, 6]

# Autoencoder
LATENT_DIM = 256
# Quality profile: better anomaly detection (slower training)
BATCH_SIZE = 128
BASE_CHANNELS = 64
LEARNING_RATE = 3e-4
EPOCHS = 140
PATIENCE = 20

ANOMALY_QUANTILE = 0.98

RANDOM_SEED = 42

MIMII_ZENODO_IDS = {
    "fan":    "3384388",
    "pump":   "3384388",
    "slider": "3384388",
    "valve":  "3384388",
}
