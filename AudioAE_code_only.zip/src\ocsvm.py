"""Bonus: One-Class SVM baseline on MFCC features."""

import numpy as np
from sklearn.svm import OneClassSVM
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from src.dataset import discover_files, load_audio, window_signal, extract_mfcc
from src.evaluate import partial_auc


def extract_mfcc_features(windows: list[np.ndarray]) -> np.ndarray:
    """Extract mean+std of MFCC across time for each window."""
    feats = []
    for w in windows:
        mfcc = extract_mfcc(w)
        feat = np.concatenate([mfcc.mean(axis=1), mfcc.std(axis=1)])
        feats.append(feat)
    return np.array(feats)


def run_ocsvm_baseline(machine_type: str, snr_db: int = 6,
                       kernel: str = "rbf", nu: float = 0.05):
    """Train One-Class SVM on normal MFCC features, evaluate on test set."""
    files = discover_files(machine_type, snr_db)

    normal_wins = []
    for mid, paths in files["normal"].items():
        for p in paths:
            y = load_audio(p)
            normal_wins.extend(window_signal(y))

    abnormal_wins = []
    for mid, paths in files["abnormal"].items():
        for p in paths:
            y = load_audio(p)
            abnormal_wins.extend(window_signal(y))

    rng = np.random.default_rng(42)
    n = len(normal_wins)
    indices = rng.permutation(n)
    n_test = int(n * 0.15)
    train_wins = [normal_wins[i] for i in indices[n_test:]]
    test_normal_wins = [normal_wins[i] for i in indices[:n_test]]

    print("Extracting MFCC features...")
    X_train = extract_mfcc_features(train_wins)
    X_test_normal = extract_mfcc_features(test_normal_wins)
    X_test_abnormal = extract_mfcc_features(abnormal_wins)

    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test_normal = scaler.transform(X_test_normal)
    X_test_abnormal = scaler.transform(X_test_abnormal)

    print(f"Training OC-SVM (kernel={kernel}, nu={nu})...")
    ocsvm = OneClassSVM(kernel=kernel, nu=nu, gamma="scale")
    ocsvm.fit(X_train)

    X_test = np.concatenate([X_test_normal, X_test_abnormal])
    y_test = np.array([0] * len(X_test_normal) + [1] * len(X_test_abnormal))

    # decision_function: negative = anomaly
    scores = -ocsvm.decision_function(X_test)

    auc = roc_auc_score(y_test, scores)
    pauc = partial_auc(y_test, scores, max_fpr=0.1)

    print(f"OC-SVM Results [{machine_type} @ {snr_db}dB]:")
    print(f"  AUC-ROC: {auc:.4f}")
    print(f"  pAUC(FPR≤0.1): {pauc:.4f}")

    return {"auc_roc": auc, "pauc_01": pauc, "scores": scores, "labels": y_test}
