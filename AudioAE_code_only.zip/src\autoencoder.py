"""Convolutional Autoencoder for anomaly detection via reconstruction error."""

import torch
import torch.nn as nn
import numpy as np
from pathlib import Path

from src.config import LATENT_DIM, N_MELS, BASE_CHANNELS


class Encoder(nn.Module):
    def __init__(self, latent_dim: int = LATENT_DIM):
        super().__init__()
        c = BASE_CHANNELS
        self.conv = nn.Sequential(
            nn.Conv2d(1, c, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(c),
            nn.ReLU(),
            nn.Conv2d(c, c * 2, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(c * 2),
            nn.ReLU(),
            nn.Conv2d(c * 2, c * 4, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(c * 4),
            nn.ReLU(),
            nn.Conv2d(c * 4, c * 8, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(c * 8),
            nn.ReLU(),
        )
        self.latent_dim = latent_dim
        self._fc = None  # lazily initialized

    def _init_fc(self, x: torch.Tensor):
        flat_size = x.shape[1] * x.shape[2] * x.shape[3]
        self._fc = nn.Linear(flat_size, self.latent_dim).to(x.device)
        self._conv_shape = x.shape[1:]  # (C, H, W) for decoder

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.conv(x)
        if self._fc is None:
            self._init_fc(h)
        return self._fc(h.flatten(1))


class Decoder(nn.Module):
    def __init__(self, latent_dim: int = LATENT_DIM):
        super().__init__()
        self.latent_dim = latent_dim
        self._fc = None
        c = BASE_CHANNELS
        self.deconv = nn.Sequential(
            nn.ConvTranspose2d(c * 8, c * 4, kernel_size=3, stride=2, padding=1, output_padding=1),
            nn.BatchNorm2d(c * 4),
            nn.ReLU(),
            nn.ConvTranspose2d(c * 4, c * 2, kernel_size=3, stride=2, padding=1, output_padding=1),
            nn.BatchNorm2d(c * 2),
            nn.ReLU(),
            nn.ConvTranspose2d(c * 2, c, kernel_size=3, stride=2, padding=1, output_padding=1),
            nn.BatchNorm2d(c),
            nn.ReLU(),
            nn.ConvTranspose2d(c, 1, kernel_size=3, stride=2, padding=1, output_padding=1),
        )

    def _init_fc(self, conv_shape: tuple):
        self._conv_shape = conv_shape
        flat_size = int(np.prod(conv_shape))
        self._fc = nn.Linear(self.latent_dim, flat_size)

    def forward(self, z: torch.Tensor, target_shape: tuple) -> torch.Tensor:
        if self._fc is None:
            raise RuntimeError("Decoder._init_fc must be called before forward")
        h = self._fc(z)
        h = h.view(-1, *self._conv_shape)
        out = self.deconv(h)
        # crop/pad to match target spatial dims
        out = out[:, :, :target_shape[2], :target_shape[3]]
        return out


class ConvAutoencoder(nn.Module):
    def __init__(self, latent_dim: int = LATENT_DIM):
        super().__init__()
        self.encoder = Encoder(latent_dim)
        self.decoder = Decoder(latent_dim)
        self._initialized = False

    def _lazy_init(self, x: torch.Tensor):
        """Run a forward pass through encoder to determine shapes, then init decoder."""
        with torch.no_grad():
            _ = self.encoder(x[:1])
        self.decoder._init_fc(self.encoder._conv_shape)
        self.decoder = self.decoder.to(x.device)
        self._initialized = True

    def forward(self, x: torch.Tensor):
        if not self._initialized:
            self._lazy_init(x)
        z = self.encoder(x)
        x_hat = self.decoder(z, x.shape)
        return x_hat, z

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        if not self._initialized:
            self._lazy_init(x)
        return self.encoder(x)

    def reconstruction_error(self, x: torch.Tensor) -> torch.Tensor:
        """Per-sample MSE reconstruction error."""
        x_hat, _ = self(x)
        err = ((x - x_hat) ** 2).mean(dim=(1, 2, 3))
        return err


def train_autoencoder(model: ConvAutoencoder, train_loader, val_loader,
                      epochs: int, lr: float, patience: int,
                      device: torch.device, save_path: Path | None = None):
    """Train autoencoder with early stopping on validation MSE."""
    model = model.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.MSELoss()

    best_val_loss = float("inf")
    wait = 0
    history = {"train_loss": [], "val_loss": []}

    for epoch in range(1, epochs + 1):
        model.train()
        train_losses = []
        for batch in train_loader:
            if isinstance(batch, (list, tuple)):
                x = batch[0]
            else:
                x = batch
            x = x.to(device)
            x_hat, _ = model(x)
            loss = criterion(x_hat, x)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            train_losses.append(loss.item())

        model.eval()
        val_losses = []
        with torch.no_grad():
            for batch in val_loader:
                if isinstance(batch, (list, tuple)):
                    x = batch[0]
                else:
                    x = batch
                x = x.to(device)
                x_hat, _ = model(x)
                loss = criterion(x_hat, x)
                val_losses.append(loss.item())

        t_loss = np.mean(train_losses)
        v_loss = np.mean(val_losses)
        history["train_loss"].append(t_loss)
        history["val_loss"].append(v_loss)

        print(f"Epoch {epoch:3d} | train_loss={t_loss:.4f} | val_loss={v_loss:.4f}")

        if v_loss < best_val_loss:
            best_val_loss = v_loss
            wait = 0
            if save_path:
                save_path.parent.mkdir(parents=True, exist_ok=True)
                torch.save(model.state_dict(), save_path)
        else:
            wait += 1
            if wait >= patience:
                print(f"Early stopping at epoch {epoch}")
                break

    if save_path and save_path.exists():
        model.load_state_dict(torch.load(save_path, weights_only=True))

    return model, history


def compute_threshold(model: ConvAutoencoder, val_loader,
                      device: torch.device, quantile: float = 0.95) -> float:
    """Compute anomaly threshold from reconstruction errors on normal validation set."""
    model.eval()
    errors = []
    with torch.no_grad():
        for batch in val_loader:
            if isinstance(batch, (list, tuple)):
                x = batch[0]
            else:
                x = batch
            x = x.to(device)
            err = model.reconstruction_error(x)
            errors.extend(err.cpu().numpy())
    threshold = np.quantile(errors, quantile)
    print(f"Anomaly threshold (q={quantile}): {threshold:.6f}")
    return threshold
