"""Dataset loading, windowing, feature extraction, and augmentation."""

import numpy as np
import librosa
import soundfile as sf
import torch
from torch.utils.data import Dataset, TensorDataset
from pathlib import Path
from typing import Literal
import logging

from src.config import (
    DATA_DIR, SAMPLE_RATE, WINDOW_SEC, HOP_SEC,
    N_FFT, HOP_LENGTH, N_MELS, N_MFCC, RANDOM_SEED,
)

logger = logging.getLogger(__name__)


def discover_files(machine_type: str, snr_db: int = 6):
    base = DATA_DIR / machine_type
    result = {"normal": {}, "abnormal": {}}

    if not base.exists():
        raise FileNotFoundError(
            f"Data not found: {base}\nDownload '{machine_type}' first."
        )

    for mid_dir in sorted(base.iterdir()):
        if not mid_dir.is_dir():
            continue
        mid = mid_dir.name
        for label in ("normal", "abnormal"):
            label_dir = mid_dir / label
            if label_dir.exists():
                files = sorted(label_dir.glob("*.wav"))
                if files:
                    result[label].setdefault(mid, []).extend(files)

    return result


def load_audio(path: Path, sr: int = SAMPLE_RATE) -> np.ndarray:
    y, file_sr = sf.read(str(path), dtype="float32", always_2d=False)
    if y.ndim > 1:
        y = y.mean(axis=1)
    if file_sr != sr:
        y = librosa.resample(y, orig_sr=file_sr, target_sr=sr)
    return y.astype(np.float32, copy=False)


def window_signal(y: np.ndarray, sr: int = SAMPLE_RATE,
                   window_sec: float = WINDOW_SEC,
                   hop_sec: float = HOP_SEC) -> list[np.ndarray]:
    win_len = int(window_sec * sr)
    hop_len = int(hop_sec * sr)
    windows = []
    start = 0
    while start + win_len <= len(y):
        windows.append(y[start:start + win_len])
        start += hop_len
    return windows


def extract_mel_spectrogram(y: np.ndarray, sr: int = SAMPLE_RATE) -> np.ndarray:
    S = librosa.feature.melspectrogram(
        y=y, sr=sr, n_fft=N_FFT, hop_length=HOP_LENGTH, n_mels=N_MELS,
    )
    log_S = librosa.power_to_db(S, ref=np.max)
    return log_S


def extract_mfcc(y: np.ndarray, sr: int = SAMPLE_RATE) -> np.ndarray:
    mfcc = librosa.feature.mfcc(
        y=y, sr=sr, n_mfcc=N_MFCC, n_fft=N_FFT, hop_length=HOP_LENGTH,
    )
    return mfcc


def add_noise(y: np.ndarray, noise_level: float = 0.005) -> np.ndarray:
    rng = np.random.default_rng()
    noise = rng.normal(0, noise_level, y.shape)
    return y + noise


def change_volume(y: np.ndarray, gain_range: tuple = (0.7, 1.3)) -> np.ndarray:
    rng = np.random.default_rng()
    gain = rng.uniform(*gain_range)
    return y * gain


def augment_waveform(y: np.ndarray) -> np.ndarray:
    """Fast augmentations only (no time_stretch)."""
    rng = np.random.default_rng()
    out = y.copy()
    if rng.random() < 0.5:
        out = add_noise(out)
    if rng.random() < 0.5:
        out = change_volume(out)
    return out


def spec_augment(mel: torch.Tensor, freq_mask_param: int = 8, time_mask_param: int = 16) -> torch.Tensor:
    """SpecAugment on mel tensor (1, n_mels, T) — runs on GPU."""
    rng = torch.rand(2)
    if rng[0] < 0.5:
        f = torch.randint(1, freq_mask_param + 1, (1,)).item()
        f0 = torch.randint(0, mel.shape[1] - f + 1, (1,)).item()
        mel = mel.clone()
        mel[:, f0:f0 + f, :] = 0.0
    if rng[1] < 0.5:
        t = torch.randint(1, time_mask_param + 1, (1,)).item()
        t0 = torch.randint(0, mel.shape[2] - t + 1, (1,)).item()
        mel = mel.clone()
        mel[:, :, t0:t0 + t] = 0.0
    return mel


class PrecomputedMelDataset(Dataset):
    """Precomputes ALL mel spectrograms once in __init__ → zero CPU overhead during training."""

    def __init__(self, windows: list[np.ndarray], labels: np.ndarray | None = None,
                 augment_normal: bool = False, sr: int = SAMPLE_RATE,
                 progress_cb=None):
        self.labels = labels
        self.augment_normal = augment_normal
        n = len(windows)
        logger.info(f"Precomputing {n} mel spectrograms...")

        # Compute all spectrograms upfront
        specs = []
        for i, y in enumerate(windows):
            if augment_normal and (labels is None or labels[i] == 0):
                y = augment_waveform(y)
            mel = extract_mel_spectrogram(y, sr)
            specs.append(mel)
            if progress_cb and i % 500 == 0 and i > 0:
                progress_cb(i, n)

        # Stack into single tensor (N, 1, n_mels, T)
        arr = np.stack(specs, axis=0)
        self.data = torch.from_numpy(arr).float().unsqueeze(1)  # (N, 1, n_mels, T)

        if labels is not None:
            self.label_tensor = torch.from_numpy(labels).long()
        else:
            self.label_tensor = None

        logger.info(f"Precomputed tensor shape: {list(self.data.shape)}")

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        x = self.data[idx]
        if self.augment_normal:
            x = spec_augment(x)
        if self.label_tensor is not None:
            return x, int(self.label_tensor[idx])
        return x


# Keep old name as alias for compatibility
MelSpectrogramDataset = PrecomputedMelDataset


def build_datasets(machine_type: str, snr_db: int = 6,
                   val_ratio: float = 0.15, test_ratio: float = 0.15,
                   augment_train: bool = True, seed: int = RANDOM_SEED,
                   progress_cb=None):
    rng = np.random.default_rng(seed)
    files_info = discover_files(machine_type, snr_db)

    normal_windows = []
    abnormal_windows = []
    abnormal_ids = []
    n_normal_files = sum(len(v) for v in files_info["normal"].values())
    n_abnormal_files = sum(len(v) for v in files_info["abnormal"].values())
    total_files = n_normal_files + n_abnormal_files
    processed_files = 0

    for mid, paths in files_info["normal"].items():
        for p in paths:
            y = load_audio(p)
            wins = window_signal(y)
            normal_windows.extend(wins)
            processed_files += 1
            if progress_cb and (processed_files % 25 == 0 or processed_files == total_files):
                progress_cb(processed_files, total_files)

    for mid, paths in files_info["abnormal"].items():
        for p in paths:
            y = load_audio(p)
            wins = window_signal(y)
            abnormal_windows.extend(wins)
            abnormal_ids.extend([mid] * len(wins))
            processed_files += 1
            if progress_cb and (processed_files % 25 == 0 or processed_files == total_files):
                progress_cb(processed_files, total_files)

    if not normal_windows:
        raise FileNotFoundError(
            f"No normal audio files found for {machine_type} @ {snr_db}dB"
        )

    n = len(normal_windows)
    indices = rng.permutation(n)

    n_test = int(n * test_ratio)
    n_val = int(n * val_ratio)

    test_idx = indices[:n_test]
    val_idx = indices[n_test:n_test + n_val]
    train_idx = indices[n_test + n_val:]

    train_windows = [normal_windows[i] for i in train_idx]
    val_normal_windows = [normal_windows[i] for i in val_idx]
    test_normal_windows = [normal_windows[i] for i in test_idx]

    test_windows = test_normal_windows + abnormal_windows
    test_labels = np.array(
        [0] * len(test_normal_windows) + [1] * len(abnormal_windows)
    )
    test_abnormal_ids = [None] * len(test_normal_windows) + abnormal_ids

    logger.info(f"[{machine_type} @ {snr_db}dB] train={len(train_windows)} "
                f"val={len(val_normal_windows)} test_normal={len(test_normal_windows)} "
                f"test_abnormal={len(abnormal_windows)}")

    train_ds = PrecomputedMelDataset(train_windows, augment_normal=augment_train,
                                     progress_cb=progress_cb)
    val_ds = PrecomputedMelDataset(val_normal_windows)
    test_ds = PrecomputedMelDataset(test_windows, labels=test_labels)

    print(f"[{machine_type} @ {snr_db}dB] train={len(train_windows)}  "
          f"val={len(val_normal_windows)}  test_normal={len(test_normal_windows)}  "
          f"test_abnormal={len(abnormal_windows)}")

    return train_ds, val_ds, test_ds, test_labels, test_abnormal_ids
