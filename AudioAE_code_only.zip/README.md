# Acoustic Diagnostics (GUI-only)

Минимальный GUI для проверки своих `.wav` файлов на аномалии по reconstruction error автоэнкодера.

## Что оставлено

- Web GUI (`Flask`)
- Загрузка нескольких пользовательских `.wav`
- Проверка по модели `models/autoencoder_<machine>.pt`
- Вывод результата по каждому файлу: `mean_error`, `max_error`, `ANOMALY/NORMAL`

## Быстрый старт

1. Установить зависимости:

```bash
pip install -r requirements.txt
```

2. Подготовить модель(и):

- `models/autoencoder_fan.pt`
- `models/autoencoder_pump.pt`
- `models/autoencoder_slider.pt`
- `models/autoencoder_valve.pt`

Можно иметь только нужные типы машин, которые собираетесь проверять в GUI.

3. Запустить GUI:

```bash
python app.py
```

или через `start.bat`.

4. Открыть в браузере:

[http://localhost:228](http://localhost:228)

## Использование

- Выберите тип машины.
- Укажите порог аномалии (`Threshold`).
- Загрузите один или несколько `.wav`.
- Нажмите **"Загрузить и проверить"**.

## Ограничения

- Поддерживаются только `.wav`.
- Если у файла слишком короткий сигнал и не получается извлечь окно, для него будет отметка `No windows extracted`.
- Для выбранного типа машины должен существовать соответствующий файл модели в `models/`.
